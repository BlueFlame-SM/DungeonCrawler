**Title game**: STYX

Developed in Game engine Godot, read LISENCE.md for availability


**Description:**
DungeonCrawler is a game where you go through levels in a 2D world.
Each level is either a lootroom or a fightroom. In a lootroom you can open
a chest to find usefull items. In a fightroom you have to fight enemies after which
you earn items with more chance at more rare items. You can make choices that influence the
game such as wich items to use and by chosing between two doors for the next level.
The game is won after beating the endboss.


**Guide players:**

Download tarfile DungeonCrawlerExacutable


**Guide Contributers:**
1. Install Godot engine: https://godotengine.org/download/linux
2. Clone repository
3. In Godot engine click "IMPORT" and select project.godot from the cloned repository
4. The main scene is res://interface/main_menu (this is already set when you open the project)


**Files game development progression:**

Notulen:
https://docs.google.com/document/d/1UHgV871afOeHcjqzH3PNGwz6D1NnC2l-zHhNkmQV9mc/edit?usp=sharing

Items:
https://docs.google.com/document/d/1oVRcXGDCauN2EQRkg_3sK2dU6C8ZlpkrIgdM-7srU_4/edit?usp=sharing

Enemies:
https://docs.google.com/document/d/1cmWADQ-cFN5owzd0HY3cwC2X2t8OprcN5GLwvYnreEM/edit?usp=sharing

Agenda:
https://docs.google.com/spreadsheets/d/1eO9IDSayotqlMNERWH-zEk_pjOx9J_3VT0gsljjKTYg/edit#gid=0
